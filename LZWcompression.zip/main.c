#include "dic.h"

static Comp startComp()
{
   Comp comp;
   comp.root = NULL;
   comp.current = NULL;
   comp.code = 0;
   comp.rec = 12;
   comp.dict = 256;
   comp.cap = 2;
   comp.input = NULL;
   comp.currLimit = 512;

   return comp;
}

static Out startOut()
{
   Out out; 

   out.output = NULL;
   out.buffer = 0;
   out.remainder = 0;
   out.bits = 9;

   return out;
}

static void printUsage()
{
   fprintf(stderr,"Usage: lzwCompress [-rN] file\n");
   fprintf(stderr,"Where: N is a number from 9 to 15 specifying");
   fprintf(stderr," the recycle code as a power of 2\n");
   exit(EXIT_FAILURE);
}

static void openFile(char fname[],Comp *comp)
{
   if((comp->input = fopen(fname,"r")) == NULL)
   {
      fprintf(stderr,"lzwCompress: %s: ",fname);
      perror(NULL);
      exit(EXIT_FAILURE);
   }
}

void createLzw(char fname[], Out *out)
{
   strcat(fname,".lzw");
   if((out->output = fopen(fname,"w")) == NULL)
   {
      fprintf(stderr,"lzwCompress: %s: ",fname);
      perror(NULL);
      exit(EXIT_FAILURE);
   }
}

static void checkArgs(int argc, char *argv[],Comp *comp, Out *out)
{
   int i;
   char *fileName = NULL;
   if(argc < 2 || argc > 3)
      printUsage();

   for(i = 1; i < argc;i++)
   {
      if(argv[i][0] == '-')
      {
         if(sscanf(argv[i],"-r%d",&(comp->rec)) <= 0 || 
            comp->rec < 9 || comp->rec > 15)
            printUsage();
      }
      else
      {
         fileName = argv[i];
      }
   }
   openFile(fileName,comp);
   createLzw(fileName,out);
}

void getLimit(Comp *comp)
{
   int i;
   for(i = 0 ; i < (comp->rec - 1);i++)
   {
      comp->cap *= 2;
   }
}

void printEOF(Comp *comp, Out *out)
{
   comp->code = EOF_MARKER;
   output(comp,out);
   fprintf(out->output,"%c",out->buffer);
   fclose(out->output);
}

int main(int argc, char *argv[])
{
   int c;
   Comp comp;
   Out out;
   comp = startComp();
   out = startOut();
   checkArgs(argc,argv,&comp,&out);

   getLimit(&comp);

   comp.root = makeRoot();
   comp.current = &(comp.root);
   
   if(getc(comp.input) == EOF)
   {
      freeRoot(comp.root);
      fclose(comp.input);
      fclose(out.output);
      exit(EXIT_SUCCESS);
   }
   rewind(comp.input);

   fprintf(out.output,"%c",comp.rec);
   
   while((c = getc(comp.input)) != EOF)
   {
      input(c,&comp,&out);
   }
   if(comp.dict == comp.currLimit)
   {
      out.bits++;
   }
   output(&comp,&out);

   printEOF(&comp,&out);
   
   freeRoot(comp.root);
   
   fclose(comp.input);
   return EXIT_SUCCESS;
}
