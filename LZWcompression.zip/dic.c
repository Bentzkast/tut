#include "dic.h"

static TrieNode* makeNode()
{
   TrieNode *node;
   int i;
   if((node = malloc(sizeof(TrieNode))) == NULL)
   {
      perror(NULL);
      exit(EXIT_FAILURE);
   }

   for(i = 0; i < NUMBER_OF_SYMBOLS;i++)
   {
      (node->code)[i] = EOF_MARKER;
      (node->next)[i] = NULL;
   }   

   return node;
}

static Code search(TrieNode** current,int new)
{
   if(*current == NULL)
      return EOF_MARKER;
   if(((*current)->code)[new] != EOF_MARKER)
      return ((*current)->code)[new];
   else
      return EOF_MARKER;
}

static void insert(TrieNode** current, int new, unsigned short dict)
{
   if(*current == NULL)
   {
      *current = makeNode();
   }
   ((*current)->code)[new] = dict;
}

TrieNode* makeRoot()
{
   TrieNode *root;
   int i;
   root = makeNode();
   for(i = 0; i < NUMBER_OF_SYMBOLS;i++)
      (root->code)[i] = i;
   return root;
}

TrieNode* freeRoot(TrieNode *root)
{
   int i;
   for(i = 0; i < NUMBER_OF_SYMBOLS;i++)
   {
      if((root->next)[i] != NULL)
         freeRoot((root->next)[i]);
   }
   free(root);
   root = NULL;
   return root;
}

void output(Comp *comp,Out *out)
{
   Code pout = 0;
   
   pout = comp->code >> (out->bits - 8 + out->remainder);
   pout |= out->buffer;
   fprintf(out->output,"%c",pout);
   
   if(out->remainder + out->bits > 16)
   {
      pout = comp->code >> (out->bits  - 16 + out->remainder);
      fprintf(out->output,"%c",pout); 
      out->buffer = comp->code << (24 - out->bits - out->remainder);
      out->remainder = out->bits - 16 + out->remainder;
   }
   else
   {
      out->buffer = comp->code << (16 - out->bits - out->remainder);
      out->remainder = out->bits - 8 + out->remainder;
   }
}
void updateBit(Comp *comp,Out *out)
{
   if(comp->dict > comp->currLimit)
   {
      comp->currLimit *= 2;
      (out->bits)++;
   }
}

void input(int c, Comp *comp, Out *out)
{
   Code result;

   result = search(comp->current,c);
   if(result == EOF_MARKER)
   {
      (comp->dict)++;
      updateBit(comp,out);
      if(comp->dict == comp->cap)
      {
         comp->dict = NUMBER_OF_SYMBOLS;
         output(comp,out);
         comp->root = freeRoot(comp->root);
         comp->root = makeRoot();
         out->bits = 9;
         comp->currLimit = 512;
      }
      else{
         insert(comp->current,c,comp->dict);  
         output(comp,out);
      }
      comp->current = &(((comp->root)->next)[c]);
      comp->code = c;
   }
   else
   {
      comp->code = result;
      comp->current = &(((*(comp->current))->next)[c]);
   }
}
