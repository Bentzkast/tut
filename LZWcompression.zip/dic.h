#ifndef DIC_H
#define DIC_H
#include "comp.h"

/*void input(int c, TrieNode **root,TrieNode ***current, Code * code, 
   unsigned short *dict,unsigned short cap);
*/

void input(int c,Comp *comp,Out *out);
void output(Comp * comp, Out *out);
void updateBit(Comp *comp, Out *out);

TrieNode* makeRoot();
TrieNode* freeRoot();

#endif
