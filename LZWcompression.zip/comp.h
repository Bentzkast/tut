#ifndef COMP_H
#define COMP_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define NUMBER_OF_SYMBOLS 256
#define EOF_MARKER 256

typedef unsigned Code;

typedef struct trieNode
{
   Code code[NUMBER_OF_SYMBOLS];
   struct trieNode *next[NUMBER_OF_SYMBOLS];
}TrieNode;

typedef struct
{
   TrieNode *root;
   TrieNode **current;
   Code code;
   int rec;
   unsigned short dict;
   unsigned short cap;
   unsigned short currLimit;
   FILE *input;
}Comp;

typedef struct
{
   FILE *output;
   Code buffer;
   int remainder;
   int bits;
}Out;

#endif
