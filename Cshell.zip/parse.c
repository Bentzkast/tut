#include "parse.h"

static char* split(char **tok, char **next, char *str, const char *delim)
{
   char *m;

   if(delim == NULL)
      return NULL;
   *tok = (str) ? str : *next;
   if(*tok == NULL)
      return NULL;

   m = strstr(*tok,delim);

   if(m)
   {
      *next = m + strlen(delim);
      *m = '\0';
   }
   else
      *next = NULL;
   
   return *tok;
}

int getLine(char line [LINE_MAX])
{  
   char *temp = NULL;
   size_t tempSize = 0;
   
   if(getline(&temp, &tempSize, stdin) > LINE_MAX)
   {  
      fprintf(stdout,"cshell: Command line too long\n");
      return EXIT_FAILURE;
   }
   strcpy(line,temp);
   line[strlen(line) - 1] = '\0';
   return EXIT_SUCCESS;
}

static int setReIn(char **arg,Commands *cmd, char cmds[],const char delim[])
{
   char *fName;  
   
   if((*arg = strtok(NULL,delim)) != NULL)
   {
      cmd->reIn = 1;
      fName = *arg;
      cmd->inFile = fName;
   }
   return EXIT_SUCCESS;
}

static int setReOut(char **arg, Commands *cmd, char cmds[],const char delim[])
{
   char *fName;
   
   if((*arg = strtok(NULL,delim)) != NULL)
   {
      /* set redirect to ON */
      cmd->reOut = 1;
      /* set next argument file to the inFile Pointer */
      fName = *arg;
      cmd->outFile = fName;
   }
   return EXIT_SUCCESS;
}

static int invPipe()
{
   printf("cshell: Invalid pipe\n");
   return EXIT_FAILURE;
}

static int tooArg(Commands *cmd)
{   
   fprintf(stdout,"cshell: %s: Too many arguments\n",(cmd->argv)[0]);
   return EXIT_FAILURE;
}

static int putToStruct(Commands *cmd,char cmds[])
{
   int argc = 0;
   const char delim[2] = " ";
   char *arg;
   
   arg = strtok(cmds,delim);
   
   if(strcmp(arg,"exit") == 0)
      exit(EXIT_SUCCESS);
   if(strcmp(arg,"") == 0)
      return EXIT_FAILURE;
   
   while(arg != NULL)
   {
      if(strcmp(arg,"|") == 0)
         return invPipe();
      if(argc > ARG_MAX - 1)
         return tooArg(cmd);

      /* check if redirection */
      if(strcmp(arg,"<") == 0)
      {
         if(setReIn(&arg,cmd,cmds,delim))
            return EXIT_FAILURE;
      }
      else if(strcmp(arg,">") == 0)
      {
         if(setReOut(&arg,cmd,cmds,delim))
            return EXIT_FAILURE;
      }
      else if(strcmp(arg,"") != 0)
      {
         (cmd->argv)[argc] = arg;
         argc++;
      } 
      arg = strtok(NULL,delim);
   }
   cmd->argc = argc;
   return EXIT_SUCCESS;
}

int parseInput(char line[LINE_MAX],Commands cmd[CMD_MAX],int *cmdCount)
{  
   char *cmds[CMD_MAX];
   char *input;
   const char delim[4] = " | ";
   char *tok,*next;
   int i;
   *cmdCount = 0; 
   
   input = split(&tok,&next,line,delim);
   while(input != NULL)
   {  
      if(*cmdCount > CMD_MAX -1)
      {  
         fprintf(stdout,"cshell: Too many commands\n");
         return EXIT_FAILURE;
      }
      cmds[*cmdCount] = input;
      (*cmdCount)++; 
      input = split(&tok,&next,NULL,delim);
   }
   
   for(i = 0; i < *cmdCount; i++)
   {
      if(putToStruct(&(cmd[i]),cmds[i]))
         return EXIT_FAILURE;
   }
  
   return EXIT_SUCCESS;
}

