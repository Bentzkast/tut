#include "exec.h"

static void initCmd(Commands c[])
{
   int i;
   int j;
   for(i = 0; i< CMD_MAX;i++)
   {
      for(j = 0; j < CMD_MAX;j++)
      {
         ((c[i]).argv)[j] = NULL;
      }
      (c[i]).argc = 0;
      (c[i]).reIn = 0;
      (c[i]).reOut = 0;
      (c[i]).inFile = NULL;
      (c[i]).outFile = NULL;
   }
}

static void shellLoop()
{
   char line[LINE_MAX];
   Commands cmd[CMD_MAX];   
   int cmdCount;

   setbuf(stdout,NULL);
   while(1)
   {
      printf(":-) ");
      initCmd(cmd);
      memset(line,0,LINE_MAX);
      getLine(line);
      
      if(feof(stdin))
      {
         printf("exit\n");
         exit(EXIT_SUCCESS);
      }
      if(!parseInput(line,cmd,&cmdCount))
         launch(cmd,cmdCount);
   }
}

int main(int argc, char **argv)
{
   int cont = 1;
   do
   {
      shellLoop(); 
   }while(cont);
  
   return EXIT_SUCCESS;
}
