#include "exec.h"
#define BUFFER_SIZE 256
#define READ_END 0
#define WRITE_END 1

static int inRe(Commands cmd[], int i, int cmdCount, int fd[2],int oldRead)
{
   int filed;
   
   if(cmd[i].reIn)
   {
      filed = open(cmd[i].inFile, O_RDONLY);
      if(filed == -1)
      {
         printf("cshell: Unable to open file for input\n");
         return EXIT_FAILURE;
      }
      
      dup2(filed,STDIN_FILENO);
   }
   /* if not the first command */
   else if( i != 0)
   {
      dup2(oldRead,STDIN_FILENO);
   }
   return EXIT_SUCCESS;
}

static int outRe(Commands cmd[], int i, int cmdCount, int fd[2])
{
   int filed;

   if(cmd[i].reOut)
   {
      filed = open(cmd[i].outFile, O_WRONLY | O_CREAT | O_TRUNC , 0666);
      if(filed == -1)
      {
         printf("cshell: Unable to open file for output\n");
         return EXIT_FAILURE;
      }
      dup2(filed,STDOUT_FILENO);
   }
   /* if still have a pipe next to it */
   else if(i + 1 < cmdCount)
   {
      dup2(fd[WRITE_END],STDOUT_FILENO);
   }
   return EXIT_SUCCESS;
}

static int makePipe(int fd[2])
{
   if(pipe(fd) == -1)
   {
      perror(NULL);
      return (EXIT_FAILURE);
   }  
   return EXIT_SUCCESS;
}

static int child(Commands cmd[],int cmdCount,int i,int fd[2],int oldRead)
{
   if(inRe(cmd,i,cmdCount,fd,oldRead))
      return EXIT_FAILURE;
   if(outRe(cmd,i,cmdCount,fd))
      return EXIT_FAILURE;

   if(execvp(((cmd[i]).argv)[0],(cmd[i]).argv) == -1)
   {
      printf("cshell: %s: Command not found\n",((cmd[i]).argv)[0]);
      exit(EXIT_FAILURE);
   }
   return EXIT_SUCCESS;
}

static int parent(int fd[],pid_t *pid,int *status, int *oldRead)
{
   close(fd[WRITE_END]);
   close(*oldRead);
   if((*pid = waitpid(*pid, status, 0)) < 0)
   {
      perror(NULL);
      return (EXIT_FAILURE);
   }
   *oldRead = fd[0];
   return EXIT_SUCCESS;
}

int launch(Commands cmd[CMD_MAX],int cmdCount)
{
   pid_t pid;
   int status;
   int i;
   int fd[2];
   int oldRead = -1;
   
   for( i = 0; i < cmdCount; i++)
   {
      
      if(makePipe(fd))
         return EXIT_FAILURE;

      pid = fork();
      if(pid == 0)
      {
         if(child(cmd,cmdCount,i,fd,oldRead))
            return EXIT_FAILURE;
      }
      else if(pid < 0)
      {
         perror(NULL);
         return (EXIT_FAILURE);
      }
      else
      {
         if(parent(fd,&pid,&status,&oldRead))
            return EXIT_FAILURE;
      }
   }
   return EXIT_SUCCESS;
}
